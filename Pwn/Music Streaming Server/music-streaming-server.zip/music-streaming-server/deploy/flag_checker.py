import inotify.adapters
import os
import subprocess

def monitor_flag_file():
    i = inotify.adapters.Inotify()
    
    flag_file = 'flag.txt'
    
    if not os.path.exists(flag_file):
        print(f"Error: File '{flag_file}' does not exist.")
        return

    try:
        i.add_watch(flag_file)
    except inotify.exc.InotifyError as e:
        print(f"Error adding watch: {e}")
        return

    print(f"Monitoring file: {flag_file}")
    
    for event in i.event_gen(yield_nones=False):
        (_, type_names, path, filename) = event
        
        if 'IN_ACCESS' in type_names:            
            os.system('pkill -f "python3 client.py"')
            os.system('pkill -f "python3 server.py"')
            os.system('pkill server')
            os.system('python3 client.py /home/chall/music/Piano.mp3 10001 &')
            os.system('python3 client.py /home/chall/music/Rap.mp3 10002 &')
            os.system('python3 client.py /home/chall/music/K-POP.mp3 10003 &')
            os.system('./server &')
            os.system('python3 server.py &')

if __name__ == "__main__":
    monitor_flag_file()