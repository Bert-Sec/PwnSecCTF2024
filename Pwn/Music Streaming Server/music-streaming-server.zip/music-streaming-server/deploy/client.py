import asyncio
import aiofiles
import zstandard as zstd
import sys
import struct

async def handle_client(reader, writer, chunk_size=0x1000):    
    compressor = zstd.ZstdCompressor()
    try:
        async with aiofiles.open(sys.argv[1], 'rb') as f:
            while True:
                chunk = await f.read(chunk_size)
                if not chunk:                    
                    writer.write(struct.pack('>I', 0))
                    await writer.drain()
                    break
                compressed_chunk = compressor.compress(chunk)           
                size_bytes = struct.pack('>I', len(compressed_chunk))                                                             
                writer.write(size_bytes)
                await writer.drain()
                writer.write(compressed_chunk)
                await writer.drain()
    except Exception as e:
        print(f"Error: {e}")
    finally:
        writer.close()        
        await writer.wait_closed()

async def main():
    server = await asyncio.start_server(
        handle_client, '0.0.0.0', int(sys.argv[2]))

    addr = server.sockets[0].getsockname()
    print(f'Serving on {addr}')

    async with server:
        await server.serve_forever()

if __name__ == '__main__':
    asyncio.run(main())
