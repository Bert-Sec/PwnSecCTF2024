from flask import Flask, Response, stream_with_context, request, render_template_string
import socket
import os

app = Flask(__name__)

SERVERS = [
    {"host": "127.0.0.1", "port": 10001, "title": "Emotinal"},
    {"host": "127.0.0.1", "port": 10002, "title": "Rap"},
    {"host": "127.0.0.1", "port": 10003, "title": "K-POP"},    
]

@app.route('/stream_audio')
def stream_audio():
    backend_host = request.args.get('host', '127.0.0.1')
    backend_port = request.args.get('port', 10001)    
    def generate():
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(2)
            try:
                s.connect(('127.0.0.1', 10005))                
                print(backend_host, backend_port)
                s.sendall(backend_host.encode('utf-8').ljust(16, b'\0'))
                s.sendall(backend_port.encode('utf-8').ljust(6, b'\0'))
                while True:
                    chunk = s.recv(4096)
                    if not chunk:
                        break
                    yield chunk
            except Exception as e:
                print(f"Error: {e}")

    return Response(stream_with_context(generate()), mimetype="audio/mpeg")

@app.route('/', methods=['GET', 'POST'])
def index():
    selected_server = request.form.get('server', '127.0.0.1:10001')
    selected_host, selected_port = selected_server.split(':')
    selected_port = int(selected_port)

    return render_template_string('''
    <!DOCTYPE html>
    <html lang="ko">
    <!-- author : Osori -->
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>🎵 MP3 Streaming Service 🪇</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
            body { background-color: #f8f9fa; }
            .container { max-width: 600px; }
        </style>
    </head>
    <body>
        <div class="container mt-5">
            <h1 class="text-center mb-4">🎵 My favorite songs 🪇</h1>
            <div class="card">
                <div class="card-body">
                    <form method="post" class="mb-4">
                        <div class="mb-3">
                            <label for="server" class="form-label">Select song:</label>
                            <select class="form-select" id="server" name="server" onchange="updateServerInfo()">
                                {% for server in servers %}
                                    <option value="{{ server['host'] }}:{{ server['port'] }}"
                                        {% if server['host'] == selected_host and server['port']|string == selected_port|string %}selected{% endif %}>
                                        {{ server['title'] }}
                                    </option>
                                {% endfor %}                                
                            </select>
                        </div>
                        <div class="mb-3" style="display:none">
                            <label for="host" class="form-label">host:</label>
                            <input type="text" class="form-control" id="host" name="host" value="{{ selected_host }}">
                        </div>
                        <div class="mb-3" style="display:none">
                            <label for="port" type="hidden" class="form-label">port:</label>
                            <input type="number" class="form-control" id="port" name="port" value="{{ selected_port }}">
                        </div>
                        <button type="submit" class="btn btn-primary">Connect!</button>
                    </form>
                    <div class="text-center">
                        <audio controls class="w-100">
                            <source src="{{ url_for('stream_audio', host=selected_host, port=selected_port) }}" type="audio/mpeg">
                            Your browser does not support the audio element.
                        </audio>
                    </div>
                </div>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script>
            function updateServerInfo() {
                var select = document.getElementById('server');
                var hostInput = document.getElementById('host');
                var portInput = document.getElementById('port');
                
                var [host, port] = select.value.split(':');
                hostInput.value = host;
                portInput.value = port;
            }                        
            updateServerInfo();
        </script>
    </body>
    </html>
    ''', servers=SERVERS, selected_host=selected_host, selected_port=selected_port)

if __name__ == '__main__':
    app.run(debug=False, host = '0.0.0.0')
