#!/bin/bash

python3 flag_checker.py &

run_as_chall() {
    while true; do
        python3 client.py /home/chall/music/Piano.mp3 10001 &
        python3 client.py /home/chall/music/Rap.mp3 10002 &
        python3 client.py /home/chall/music/K-POP.mp3 10003 &
        ./server &
        python3 server.py &    
        sleep 1200
        pkill -f "python3 client.py"
        pkill -f "python3 server.py"
        pkill server
    done
}

su chall -c "$(declare -f run_as_chall); run_as_chall"
